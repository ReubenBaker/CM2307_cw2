public abstract class Bird extends Pet {
}
