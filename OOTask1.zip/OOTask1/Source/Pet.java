public abstract class Pet { 
} 
