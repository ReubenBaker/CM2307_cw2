public abstract class SmallMammal extends Pet {
}
