public class ZebraFinch extends Bird { 
  protected String name; 

  public void setName(String aName) { name=aName; } 

  public String getName() { return name; } 

  public String classOfAnimal() { return("ZebraFinch"); } 
  
  public boolean canFly() { return true; }
}
