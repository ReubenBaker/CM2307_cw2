javac ./*.java -d ./class
java -cp ./class DiningPhilosophers
