/**
 * A simple class representing a fork.
 */
public class Fork {
    public boolean inUse = false; // Flag indicating if the fork is currently in use
}
