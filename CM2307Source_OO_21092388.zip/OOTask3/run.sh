javac -d ./class -cp ../OOTask2:. ../OOTask2/ThreadSafeCardDeck.java ./*.java
java -cp ./class ImprovedGame
