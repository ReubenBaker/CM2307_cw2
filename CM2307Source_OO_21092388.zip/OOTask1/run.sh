javac ./Source/*.java ./ImprovedClientClass/*.java -d ./class
java -cp ./class ImprovedClient
